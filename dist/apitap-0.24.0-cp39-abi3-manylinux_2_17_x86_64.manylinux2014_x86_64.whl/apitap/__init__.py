"""apitap — move whole tables between databases at wire speed, in bounded memory.

The engine is Rust (see https://apitap.dev); this package is a thin binding.

    import apitap

    report = apitap.transfer(
        "postgres://user:pass@src-host/db",
        "postgres://user:pass@dst-host/db",
        table="public.events",
    )
    print(report.rows, report.elapsed_ms)

    # Many tables — or a whole schema — through ONE resource budget:
    report = apitap.transfer(src, dst, tables=["public.events", "public.users"])
    report = apitap.transfer(src, dst, schema="public")
"""

from __future__ import annotations

from dataclasses import dataclass

from apitap._apitap import (
    __version__,
    read as _read,
    read_schema as _read_schema,
    transfer as _transfer,
    transfer_many as _transfer_many,
)

__all__ = [
    "read",
    "Reader",
    "transfer",
    "TransferReport",
    "TableResult",
    "MultiTransferError",
    "__version__",
]


@dataclass(frozen=True)
class TableResult:
    """One table's outcome inside a multi-table transfer."""

    table: str
    """Source table (the destination table has the same name)."""
    rows: int
    """Rows landed (0 on error — a failed table commits nothing)."""
    elapsed_ms: int
    """Wall-clock for this table, from the moment it got its pipes."""
    parallel: int
    """Pipes this table ran with (its slice of the shared budget)."""
    error: str | None
    """``None`` = success. A failed table never poisons its siblings: each keeps
    the single-table atomicity, so its destination holds either the previous
    table or the complete new one — never a partial."""


@dataclass(frozen=True)
class TransferReport:
    """What a transfer did."""

    rows: int
    """Rows landed in the destination (multi-table: sum over successful tables)."""
    elapsed_ms: int
    """Wall-clock duration of the whole transfer."""
    parallel: int
    """Single table: concurrent pipes actually used (0 = empty source).
    Multi-table: the shared pipe budget the tables drew from."""
    tables: tuple[TableResult, ...] | None = None
    """Per-table outcomes for a multi-table run; ``None`` for a single table."""


class MultiTransferError(RuntimeError):
    """Some tables of a multi-table run failed. The tables that succeeded ARE
    committed (each table lands atomically and independently); ``report`` holds
    the full per-table detail, ``report.tables`` includes every error."""

    def __init__(self, message: str, report: TransferReport):
        super().__init__(message)
        self.report = report

    def __reduce__(self):
        # Exceptions pickle-reconstruct via cls(*args); args holds only the
        # message, so spell out both — a worker-process failure must arrive
        # intact, report included, not die re-raising with a TypeError.
        return (MultiTransferError, (self.args[0], self.report))


class Reader:
    """A running parallel read. Consume it ONCE, whichever way you like:

    - ``reader.to_polars()`` — the one-liner (needs ``pip install polars``)
    - ``reader.lazy()`` — a polars LazyFrame: write ordinary polars
      (filter/group_by/agg) and ``.collect(engine="streaming")`` pulls the
      table through in constant memory — 10M rows fit a 256 MB container
    - ``for df in reader.batches():`` — small polars DataFrames, one per
      Arrow batch, constant memory
    - ``reader.to_parquet(path)`` — table → Parquet file, constant memory
    - ``pl.DataFrame(reader)`` / ``pa.table(reader)`` / DuckDB — via the
      Arrow PyCapsule protocol, zero-copy
    - ``reader.to_arrow()`` / ``reader.to_pandas()``

    Batches stream on demand: memory holds the batches in flight, never the
    table. With ``parallel > 1`` row order across batches is
    nondeterministic — pass ``parallel=1`` for source order, or sort the
    frame (cheaper than giving up parallel read bandwidth).
    """

    def __init__(self, src, table, cursor, parallel, query, columns=None):
        self._args = (src, table, cursor, parallel, query, columns)
        self._native = None

    def _start(self, materialize: bool):
        # The engine starts on FIRST consumption and picks its strategy
        # from how you consume: to_polars()/to_arrow() build one giant
        # batch per pipe in Rust (fewest FFI crossings, no rechunk);
        # streaming consumers get cgroup-sized batches, memory bounded.
        if self._native is None:
            src, table, cursor, parallel, query, columns = self._args
            self._native = _read(src, table, cursor=cursor, parallel=parallel,
                                 query=query, materialize=materialize,
                                 columns=columns)
        return self._native

    def __arrow_c_stream__(self, requested_schema=None):
        return self._start(False).__arrow_c_stream__(requested_schema)

    @property
    def columns(self):
        return self._start(False).columns()

    def to_polars(self):
        """The primary path: ``apitap.read(...).to_polars()``."""
        try:
            import polars as pl
        except ImportError as e:
            raise ImportError(
                "to_polars() needs polars — pip install polars "
                "(or use to_arrow() / to_pandas())"
            ) from e
        self._start(True)
        return pl.DataFrame(self)

    def to_arrow(self):
        try:
            import pyarrow as pa
        except ImportError as e:
            raise ImportError("to_arrow() needs pyarrow — pip install pyarrow") from e
        self._start(True)
        return pa.table(self)

    def to_pandas(self):
        return self.to_arrow().to_pandas()

    def lazy(self):
        """A polars LazyFrame over the STREAM — write ordinary polars and let
        ``collect(engine="streaming")`` pull batches through constant memory::

            top = (apitap.read(src, table="events")
                   .lazy()
                   .filter(pl.col("amount") > 100)
                   .group_by("status").agg(pl.len())
                   .collect(engine="streaming"))

        Ten million rows aggregate in a 256 MB container this way — the full
        DataFrame never exists. The query's COLUMN PROJECTION is pushed all
        the way into the SQL: a query touching 2 of 15 columns makes the
        server serialize and this side decode only those 2. Predicates
        and head() prune per batch. One-shot: collect once.
        """
        try:
            import polars as pl
            from polars.io.plugins import register_io_source
        except ImportError as e:
            raise ImportError(
                "lazy() needs polars >= 1.0 and pyarrow — "
                "pip install polars pyarrow"
            ) from e
        if self._native is not None:
            raise RuntimeError(
                "lazy() must be this Reader's first consumption — make a "
                "fresh apitap.read(...) for it"
            )
        src, table, cursor, parallel, query, _ = self._args

        def dtype(tag):
            if tag.startswith("decimal:"):
                _, p, s = tag.split(":")
                return pl.Decimal(int(p), int(s))
            return {
                "i16": pl.Int16, "i32": pl.Int32, "i64": pl.Int64,
                "f32": pl.Float32, "f64": pl.Float64, "bool": pl.Boolean,
                "date": pl.Date, "ts:utc": pl.Datetime("us", "UTC"),
                "ts:naive": pl.Datetime("us"), "str": pl.String,
                "bin": pl.Binary,
            }[tag]

        # Cheap schema-only probe — the engine starts LATER, inside the
        # collect, once polars has told us which columns the query needs.
        schema = pl.Schema(
            {name: dtype(tag) for name, tag, _ in _read_schema(src, table)}
        )

        def source(with_columns, predicate, n_rows, batch_size):
            import pyarrow as pa
            cols = list(with_columns) if with_columns is not None else None
            native = _read(src, table, cursor=cursor, parallel=parallel,
                           query=query, materialize=False, columns=cols)
            taken = 0
            # The engine emits exactly the requested columns in the
            # requested order — no per-batch select needed.
            for batch in pa.RecordBatchReader.from_stream(native):
                df = pl.from_arrow(batch)
                if predicate is not None:
                    df = df.filter(predicate)
                if n_rows is not None:
                    remaining = n_rows - taken
                    if remaining <= 0:
                        return
                    if df.height > remaining:
                        df = df.head(remaining)
                taken += df.height
                yield df

        return register_io_source(source, schema=schema)

    def batches(self):
        """Iterate the table as SMALL polars DataFrames — one per Arrow
        batch, constant memory, no pyarrow ceremony::

            for df in apitap.read(src, table="events").batches():
                ...   # df is a plain polars DataFrame, a few MB each
        """
        try:
            import polars as pl
            import pyarrow as pa
        except ImportError as e:
            raise ImportError(
                "batches() needs polars and pyarrow — pip install polars pyarrow"
            ) from e
        for batch in pa.RecordBatchReader.from_stream(self):
            yield pl.from_arrow(batch)

    def to_parquet(self, path, *, compression="zstd", **writer_kwargs):
        """Stream the table into a Parquet file at constant memory; returns
        the row count. ``apitap.read(src, table="t").to_parquet("t.parquet")``
        moves a 10M-row table through a 256 MB container."""
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError as e:
            raise ImportError("to_parquet() needs pyarrow — pip install pyarrow") from e
        reader = pa.RecordBatchReader.from_stream(self)
        rows = 0
        with pq.ParquetWriter(path, reader.schema, compression=compression,
                              **writer_kwargs) as w:
            for batch in reader:
                w.write_batch(batch)
                rows += batch.num_rows
        return rows


def read(
    src: str,
    table: str | None = None,
    *,
    cursor: str | None = None,
    parallel: int | None = None,
    query: str | None = None,
    columns: list[str] | None = None,
) -> Reader:
    """Read a Postgres or MySQL table straight into a DataFrame, at wire speed.

    One line, no knobs required::

        df = apitap.read("postgres://user:pass@host/db", table="public.orders").to_polars()
        df = apitap.read("mysql://user:pass@host/db", table="orders").to_polars()

    The engine runs the same parallel binary range pipes the transfer
    routes use and decodes them into Arrow batches in Rust — Python only
    ever receives buffer pointers. Memory stays bounded (batches in
    flight, sized off the cgroup limit), so big tables read fine from
    small containers.

    Args:
        src: ``postgres://`` or ``mysql://`` source URL.
        table: Source table, optionally schema-qualified.
        cursor: Integer column to range-split on (default: the integer PK;
            PK-less Postgres tables fall back to TID ranges, PK-less MySQL
            tables read as one stream).
        parallel: Concurrent range pipes; default auto. ``1`` = source order.
        query: Raw SQL instead of a table (coming next — refused loudly today).
        columns: Read only these columns, in this order (default: all).
            ``.lazy()`` fills this automatically from the query's projection.
    """
    if (table is None) == (query is None):
        raise ValueError("pass exactly one of table=…, query=…")
    if query is not None:
        raise ValueError(
            "read: query= lands next — pass table= (and optionally cursor=) today"
        )
    return Reader(src, table, cursor, parallel, query, columns)


def transfer(
    src: str,
    dst: str,
    table: str | None = None,
    *,
    tables: list[str] | dict[str, str] | None = None,
    schema: str | None = None,
    dest_table: str | None = None,
    parallel: int | None = None,
    cursor: str | None = None,
    chunk_bytes: int | None = None,
    durable: bool = True,
    mode: str = "replace",
    engine: str | None = None,
    order_by: str | None = None,
    on_cluster: str | None = None,
) -> TransferReport:
    """Copy one table, a list of tables, or a whole schema from ``src`` to ``dst``.

    Exactly one of ``table``, ``tables``, ``schema`` picks the scope. The URL
    schemes pick the route — ``postgres://``/``postgresql://``, ``mysql://``,
    ``gsheets://<spreadsheet_id>?credentials=/path/key.json`` (tabs are the
    tables, all-text, replace only), ``github://owner/repo[/dir]?ref=main``
    (CSV files are the tables, all-text, replace only),
    ``github+api://owner/repo`` (issues/PRs/commits/stars… as typed tables,
    incremental where the API allows) sources — Postgres sources additionally
    support ``mode="log_based"`` batch CDC (logical replication: every WAL
    operation, drained per scheduled run, snapshot-pinned bootstrap) —
    ``postgres://``,
    ``clickhouse://`` (``clickhouse+https://`` for TLS),
    ``bigquery://<project>/<dataset>?credentials=/path/key.json``,
    ``gcs://<bucket>[/prefix]?format=csv|parquet&credentials=/path/key.json``
    (files: one composed .csv.gz per table, or a directory of Parquet parts),
    ``s3://<bucket>[/prefix]?format=parquet&endpoint=…`` (S3/MinIO/R2, Parquet
    files), ``iceberg://<catalog-host:port>/<namespace>?warehouse=…&endpoint=…``
    (Apache Iceberg via any REST catalog; replace/append/merge are real
    snapshot commits) destinations — and
    each pair negotiates its fastest wire format (raw binary COPY passthrough,
    in-flight RowBinary transcode, raw wire decode, or gzipped parallel load jobs).
    N concurrent range pipes feed a staging table that is swapped in atomically.
    Atomic (readers never see a partial load), 0-row-guarded (an empty source never
    wipes a good table), and memory-bounded (streams with TCP backpressure).

    Multi-table runs share ONE pipe budget — the same number a single-table run
    gets, so peak memory stays at the single-table ceiling no matter how many
    tables move. Tables run largest-first over shared connection pools: big tables
    take many pipes, small ones take one and overlap. Destination tables keep
    their source names. If some tables fail, the rest keep going and a
    :class:`MultiTransferError` is raised at the end — its ``report`` lists every
    table's outcome, and the successful ones are already committed.

    Full guide: https://github.com/apitap/apitap-lib/blob/main/docs/usage.md

    Args:
        src: Source URL, e.g. ``postgres://user:pass@host:5432/db`` or
            ``mysql://user:pass@host:3306/db``.
        dst: Destination URL (Postgres or ClickHouse).
        table: One source table, optionally schema-qualified (``public.events``).
        tables: A list of source tables — moved in one call through one budget —
            or a ``{table: mode}`` dict giving EACH table its own mode in one
            call (e.g. ``{"orders": "log_based", "dim_date": "replace"}``).
            The dict form partitions by mode: bulk modes run through the
            shared-budget pipeline; all ``log_based`` tables share ONE
            replication slot (one publication, one drain pass, one snapshot-
            pinned group bootstrap, one watermark — a CDC group fails as a
            unit). A plain list with ``mode="log_based"`` is the all-CDC
            version of the same group.
        schema: Move EVERY base table of this schema — pass the name explicitly
            (Postgres: ``schema="public"``; MySQL: the database, e.g.
            ``schema="mydb"``). Postgres also brings materialized views, and
            skips partition/INHERITS children whose parent is in the same schema
            (the parent's scan covers their rows). apitap's own
            ``*__apitap_staging``/``_apitap_state`` artifacts never travel.
        dest_table: Destination table; defaults to ``table``. Single-table only.
        parallel: Concurrent range pipes (multi-table: the shared budget); default
            auto — a route-specific CPU heuristic capped by the cgroup's memory
            limit. An explicit value is never overridden.
        cursor: Numeric column to range-split on; default auto-detects the integer
            primary key. PK-less Postgres tables fall back to TID ranges; other
            sources to a single stream. Multi-table: applies to every table, so
            leave it auto unless all tables share the column.
        chunk_bytes: Bytes coalesced per send (default 4 MiB).
        mode: ``"replace"`` (default, full refresh + atomic swap), ``"append"``
            (incremental: only rows with cursor past the destination's current
            ``max(cursor)`` are loaded — stateless, the watermark lives in the data;
            bootstraps as replace when the table doesn't exist), ``"merge"``
            (Postgres destinations: incremental upsert by the destination's
            PRIMARY KEY), or ``"log_based"`` (Postgres sources: batch CDC via
            logical replication — every WAL operation incl. deletes and
            TRUNCATEs, drained per scheduled run into Postgres, ClickHouse,
            MySQL or Iceberg; first run bootstraps snapshot-pinned, the LSN
            watermark commits atomically with the data, and a table list
            shares ONE replication slot). Incremental modes require a cursor
            (integer or timestamp column). Append assumes the cursor is
            monotonic with COMMIT order — for update-prone or
            concurrently-written tables use merge with an ``updated_at``
            cursor. See docs/usage.md.
        engine: ClickHouse destinations only. Engine of the table apitap creates —
            any MergeTree-family spelling, Replicated included: ``"MergeTree"``
            (default), ``"ReplacingMergeTree(ins_dt)"``,
            ``"ReplicatedReplacingMergeTree(ins_dt)"`` (path-less: requires
            ``on_cluster``, ClickHouse mints the ``{uuid}`` ZooKeeper path only
            for ON CLUSTER DDL), … Columns named in the engine arguments are
            declared non-nullable. With ``mode="append"``, an existing
            destination is the structural authority: apitap appends into it
            as-is and only checks that the engine family, arguments, and
            ``order_by`` agree. With ``mode="replace"`` the table is rebuilt
            with this engine (an existing explicit-ZooKeeper-path Replicated
            table can't be replaced — the shadow copy would collide; use append
            or drop it first).
        order_by: ClickHouse destinations only. ORDER BY of the created table,
            e.g. ``"id"`` or ``"client_id, id"``; default = the cursor column.
            Strongly recommended with Replacing engines (it is the dedup key).
        on_cluster: ClickHouse destinations only. Run the table DDL
            ``ON CLUSTER`` this cluster. Requires a ``Replicated*`` engine so the
            data reaches the other replicas through replication.
        durable: Postgres destinations only. ``False`` loads through an UNLOGGED
            table — skipping WAL roughly halves the destination's write cost — and the
            swapped-in table REMAINS unlogged: Postgres truncates it during crash
            recovery until you run ``ALTER TABLE … SET LOGGED``. Leave ``True`` unless
            the destination is rebuildable scratch data. Other destinations ignore it.
    """
    picked = sum(x is not None for x in (table, tables, schema))
    if picked != 1:
        raise ValueError(
            "pass exactly one of table=…, tables=[…], schema=… "
            f"(got {picked} of them)"
        )

    if table is not None:
        rows, elapsed_ms, used = _transfer(
            src,
            dst,
            table,
            dest_table=dest_table,
            parallel=parallel,
            cursor=cursor,
            chunk_bytes=chunk_bytes,
            durable=durable,
            mode=mode,
            engine=engine,
            order_by=order_by,
            on_cluster=on_cluster,
        )
        return TransferReport(rows=rows, elapsed_ms=elapsed_ms, parallel=used)

    if dest_table is not None:
        raise ValueError(
            "dest_table applies to single-table transfers — multi-table runs "
            "keep the source names"
        )
    specs = None
    if isinstance(tables, dict):
        specs, tables = [(t, m) for t, m in tables.items()], None
    elapsed_ms, budget, raw = _transfer_many(
        src,
        dst,
        tables=tables,
        schema=schema,
        specs=specs,
        parallel=parallel,
        cursor=cursor,
        chunk_bytes=chunk_bytes,
        durable=durable,
        mode=mode,
        engine=engine,
        order_by=order_by,
        on_cluster=on_cluster,
    )
    results = tuple(
        TableResult(table=t, rows=r, elapsed_ms=e, parallel=p, error=err)
        for (t, r, e, p, err) in raw
    )
    report = TransferReport(
        rows=sum(t.rows for t in results if t.error is None),
        elapsed_ms=elapsed_ms,
        parallel=budget,
        tables=results,
    )
    failed = [t for t in results if t.error is not None]
    if failed:
        ok = len(results) - len(failed)
        lines = "\n".join(f"  {t.table}: {t.error}" for t in failed)
        raise MultiTransferError(
            f"{len(failed)} of {len(results)} tables failed "
            f"({ok} succeeded and ARE committed — see .report):\n{lines}",
            report,
        )
    return report
